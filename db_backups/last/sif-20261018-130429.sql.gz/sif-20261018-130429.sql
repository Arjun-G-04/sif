--
-- PostgreSQL database dump
--

\restrict cFsfGM6nP0V3ZuTeOS3wtDanxPs4rUNwhuLGl3tzLddvYLByIdyIjWyy6KRlt2r

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: db_user
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO db_user;

--
-- Name: booking_status; Type: TYPE; Schema: public; Owner: db_user
--

CREATE TYPE public.booking_status AS ENUM (
    'pending',
    'payment',
    'payment_verification',
    'payment_rejected',
    'processing',
    'rejected',
    'completed'
);


ALTER TYPE public.booking_status OWNER TO db_user;

--
-- Name: entity_type; Type: TYPE; Schema: public; Owner: db_user
--

CREATE TYPE public.entity_type AS ENUM (
    'registration',
    'equipment'
);


ALTER TYPE public.entity_type OWNER TO db_user;

--
-- Name: field_stage; Type: TYPE; Schema: public; Owner: db_user
--

CREATE TYPE public.field_stage AS ENUM (
    'initial',
    'payment'
);


ALTER TYPE public.field_stage OWNER TO db_user;

--
-- Name: field_type; Type: TYPE; Schema: public; Owner: db_user
--

CREATE TYPE public.field_type AS ENUM (
    'text',
    'date',
    'single_select',
    'multi_select',
    'file',
    'relation',
    'heading',
    'info_text',
    'group',
    'admin_file'
);


ALTER TYPE public.field_type OWNER TO db_user;

--
-- Name: otp_type; Type: TYPE; Schema: public; Owner: db_user
--

CREATE TYPE public.otp_type AS ENUM (
    'email',
    'phone'
);


ALTER TYPE public.otp_type OWNER TO db_user;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: db_user
--

CREATE TYPE public.user_role AS ENUM (
    'public',
    'admin',
    'operator'
);


ALTER TYPE public.user_role OWNER TO db_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: db_user
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO db_user;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: db_user
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO db_user;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: db_user
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.bookings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    equipment_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    status public.booking_status DEFAULT 'pending'::public.booking_status NOT NULL,
    price numeric(10,2),
    remarks text,
    rejection_reason text,
    gst numeric(10,2),
    istem_id text,
    istem_synced_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bookings OWNER TO db_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.bookings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bookings_id_seq OWNER TO db_user;

--
-- Name: bookings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.bookings_id_seq OWNED BY public.bookings.id;


--
-- Name: configurations; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.configurations (
    id integer NOT NULL,
    "officeEmail" text,
    registration_category_field_id integer,
    istem_token text,
    istem_token_expires_at timestamp without time zone,
    istem_user_mapping jsonb,
    istem_equipment_mapping jsonb,
    istem_static_defaults jsonb,
    registration_name_field_id integer
);


ALTER TABLE public.configurations OWNER TO db_user;

--
-- Name: configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.configurations_id_seq OWNER TO db_user;

--
-- Name: configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.configurations_id_seq OWNED BY public.configurations.id;


--
-- Name: equipments; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.equipments (
    id integer NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    istem_id text,
    istem_synced_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    istem_booking_mapping jsonb,
    make text DEFAULT ''::text NOT NULL,
    model text DEFAULT ''::text NOT NULL,
    department_lab text DEFAULT ''::text NOT NULL,
    usage_rate text DEFAULT ''::text NOT NULL,
    serial_number text DEFAULT ''::text NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    website_url text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.equipments OWNER TO db_user;

--
-- Name: equipments_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.equipments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.equipments_id_seq OWNER TO db_user;

--
-- Name: equipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.equipments_id_seq OWNED BY public.equipments.id;


--
-- Name: field_admin_files; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.field_admin_files (
    id integer NOT NULL,
    field_id integer NOT NULL,
    file_path text NOT NULL,
    original_name text NOT NULL
);


ALTER TABLE public.field_admin_files OWNER TO db_user;

--
-- Name: field_admin_files_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.field_admin_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.field_admin_files_id_seq OWNER TO db_user;

--
-- Name: field_admin_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.field_admin_files_id_seq OWNED BY public.field_admin_files.id;


--
-- Name: field_groups; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.field_groups (
    id integer NOT NULL,
    field_id integer NOT NULL,
    max integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.field_groups OWNER TO db_user;

--
-- Name: field_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.field_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.field_groups_id_seq OWNER TO db_user;

--
-- Name: field_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.field_groups_id_seq OWNED BY public.field_groups.id;


--
-- Name: field_options; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.field_options (
    id integer NOT NULL,
    field_id integer NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.field_options OWNER TO db_user;

--
-- Name: field_options_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.field_options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.field_options_id_seq OWNER TO db_user;

--
-- Name: field_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.field_options_id_seq OWNED BY public.field_options.id;


--
-- Name: field_relations; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.field_relations (
    id integer NOT NULL,
    field_id integer NOT NULL,
    related_entity_type public.entity_type NOT NULL,
    related_field_id integer NOT NULL
);


ALTER TABLE public.field_relations OWNER TO db_user;

--
-- Name: field_relations_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.field_relations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.field_relations_id_seq OWNER TO db_user;

--
-- Name: field_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.field_relations_id_seq OWNED BY public.field_relations.id;


--
-- Name: field_responses; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.field_responses (
    id integer NOT NULL,
    entity_type public.entity_type NOT NULL,
    entity_id integer NOT NULL,
    field_id integer NOT NULL,
    value text,
    user_id integer,
    booking_id integer,
    iteration integer DEFAULT 0 NOT NULL,
    admin_value text
);


ALTER TABLE public.field_responses OWNER TO db_user;

--
-- Name: field_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.field_responses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.field_responses_id_seq OWNER TO db_user;

--
-- Name: field_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.field_responses_id_seq OWNED BY public.field_responses.id;


--
-- Name: fields; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.fields (
    id integer NOT NULL,
    entity_type public.entity_type NOT NULL,
    name text NOT NULL,
    type public.field_type NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    entity_id integer,
    parent_id integer,
    stage public.field_stage DEFAULT 'initial'::public.field_stage NOT NULL,
    required boolean DEFAULT true NOT NULL
);


ALTER TABLE public.fields OWNER TO db_user;

--
-- Name: fields_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.fields_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fields_id_seq OWNER TO db_user;

--
-- Name: fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.fields_id_seq OWNED BY public.fields.id;


--
-- Name: operator_equipments; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.operator_equipments (
    id integer NOT NULL,
    operator_id integer NOT NULL,
    equipment_id integer NOT NULL
);


ALTER TABLE public.operator_equipments OWNER TO db_user;

--
-- Name: operator_equipments_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.operator_equipments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.operator_equipments_id_seq OWNER TO db_user;

--
-- Name: operator_equipments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.operator_equipments_id_seq OWNED BY public.operator_equipments.id;


--
-- Name: otp_verifications; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.otp_verifications (
    id integer NOT NULL,
    type public.otp_type NOT NULL,
    target text NOT NULL,
    otp_hash text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    verified boolean DEFAULT false NOT NULL,
    turnstile_token text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.otp_verifications OWNER TO db_user;

--
-- Name: otp_verifications_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.otp_verifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.otp_verifications_id_seq OWNER TO db_user;

--
-- Name: otp_verifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.otp_verifications_id_seq OWNED BY public.otp_verifications.id;


--
-- Name: registrations; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.registrations (
    id integer NOT NULL,
    password text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    accepted boolean,
    rejection_reason text
);


ALTER TABLE public.registrations OWNER TO db_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.registrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registrations_id_seq OWNER TO db_user;

--
-- Name: registrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.registrations_id_seq OWNED BY public.registrations.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: db_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role public.user_role DEFAULT 'public'::public.user_role NOT NULL,
    registration_id integer,
    reset_password_token text,
    reset_password_expires timestamp without time zone,
    active boolean DEFAULT true NOT NULL,
    istem_id text,
    istem_synced_at timestamp without time zone,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO db_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: db_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO db_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: db_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: db_user
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: bookings id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.bookings ALTER COLUMN id SET DEFAULT nextval('public.bookings_id_seq'::regclass);


--
-- Name: configurations id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.configurations ALTER COLUMN id SET DEFAULT nextval('public.configurations_id_seq'::regclass);


--
-- Name: equipments id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.equipments ALTER COLUMN id SET DEFAULT nextval('public.equipments_id_seq'::regclass);


--
-- Name: field_admin_files id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_admin_files ALTER COLUMN id SET DEFAULT nextval('public.field_admin_files_id_seq'::regclass);


--
-- Name: field_groups id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_groups ALTER COLUMN id SET DEFAULT nextval('public.field_groups_id_seq'::regclass);


--
-- Name: field_options id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_options ALTER COLUMN id SET DEFAULT nextval('public.field_options_id_seq'::regclass);


--
-- Name: field_relations id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_relations ALTER COLUMN id SET DEFAULT nextval('public.field_relations_id_seq'::regclass);


--
-- Name: field_responses id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_responses ALTER COLUMN id SET DEFAULT nextval('public.field_responses_id_seq'::regclass);


--
-- Name: fields id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.fields ALTER COLUMN id SET DEFAULT nextval('public.fields_id_seq'::regclass);


--
-- Name: operator_equipments id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.operator_equipments ALTER COLUMN id SET DEFAULT nextval('public.operator_equipments_id_seq'::regclass);


--
-- Name: otp_verifications id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.otp_verifications ALTER COLUMN id SET DEFAULT nextval('public.otp_verifications_id_seq'::regclass);


--
-- Name: registrations id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.registrations ALTER COLUMN id SET DEFAULT nextval('public.registrations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: db_user
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	35a02e305271f772ea4a47d5be42f89e64cd7402ef4319b38bd955b898309cd3	1766556218995
2	2b6bffe118ec66b9bb9dd10ade64fd783137c15842ef09d8fed5ecadc0bd8325	1766943790358
3	11c3b4aea933d7675c428a6eadcdbe602e369fff4863bbd70285fa7f3fe1c1f0	1767191562922
4	796f5dc5063a69a419857d65834d611d77750e3c438a03602897216fa5a3d52c	1767202692207
5	efaf21c6f3c3d7a949863ed0917d39ddd44556ca5b5350a41d1105b584af377e	1767336038744
6	97339368022717683781749358dc62db4ffc798e9364392af7f0fe712899709b	1767938698138
7	400575ed54c72a48e5fabee625e76117aaa783270ddf3870a1626609d5f83abd	1769868700555
8	ee1b51dc71f31b8b67421ac62526cd254623bb850008c7c2ad149c17e44afebb	1770040644093
9	bdd41e2fd76e04358c13d42e16c0d273c6de5558fa02cbeb35e21245af11348c	1770526253130
10	0ee7c87501bc1186519ce74e92b10e52d21e41f8ee0d056398c015e4ab31cccd	1771947835984
11	ded7c9d3ad86a94d1785c3695d33547c58f0d5fff186b03566e325ea91c359c2	1776836906390
12	c968ae85c4658b7a88e718fa764b1b91533701264d6f207a7041492f67a3eb2a	1779727525678
13	a665662d533e52609e253b94d1c1fd0e9edfd0b575ec09451354060afcc5e5af	1779730899952
14	527b00758053dee77edc0c03d3c2a3295e30f16e160dea74ac13571a2ca431eb	1780326331764
15	cf34a14e7369970985932d2771a2b7a1ee08382167a12e72fa40fa4746dbe1db	1781603575086
16	24c747a62325e3e50999bbebca3065c1b912bc02c9eef9b398b5f213898d186c	1782963311768
17	aa09212dc17906cd9712a7ebb61ba67ce67d29e953d3b9e2fd4b793b3296db5a	1782981005074
18	01532ec409c1190f3919c996c0ba6d492a43bfd8dd4199ef86e8241e4d4df756	1787056065912
19	b3e20fa22ea0fadc9b7bed280937228a79a51a4de83ab1f02ef4cbed09529050	1787663528264
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.bookings (id, user_id, equipment_id, created_at, status, price, remarks, rejection_reason, gst, istem_id, istem_synced_at, updated_at) FROM stdin;
1	6	1	2026-05-01 09:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
2	10	1	2026-05-08 10:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-05-08 10:00:00
3	11	1	2026-06-04 09:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
4	12	1	2026-06-11 10:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
5	13	1	2026-06-18 11:00:00	completed	4800.00	Sample analysis completed	\N	\N	\N	\N	2026-06-18 11:00:00
6	6	1	2026-07-07 09:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
7	10	1	2026-07-14 10:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
8	11	1	2026-07-21 11:00:00	completed	4800.00	Sample analysis completed	\N	\N	\N	\N	2026-07-21 11:00:00
9	12	1	2026-07-28 12:00:00	completed	6000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-28 12:00:00
10	13	1	2026-08-10 09:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
11	6	1	2026-08-17 10:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
12	10	1	2026-08-24 11:00:00	completed	4800.00	Sample analysis completed	\N	\N	\N	\N	2026-08-24 11:00:00
13	11	1	2026-09-13 09:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
14	12	1	2026-09-20 10:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
15	13	1	2026-09-27 11:00:00	completed	4800.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
16	6	1	2026-09-05 12:00:00	completed	6000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-05 12:00:00
17	10	1	2026-10-16 09:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
18	11	1	2026-10-06 10:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
19	12	1	2026-10-13 11:00:00	completed	4800.00	Sample analysis completed	\N	\N	\N	\N	2026-10-13 11:00:00
20	13	2	2026-05-01 09:00:00	completed	1000.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
21	6	2	2026-05-08 10:00:00	completed	1500.00	Sample analysis completed	\N	\N	\N	\N	2026-05-08 10:00:00
22	10	2	2026-05-15 11:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-05-15 11:00:00
23	11	2	2026-06-04 09:00:00	completed	1000.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
24	12	2	2026-06-11 10:00:00	completed	1500.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
25	13	2	2026-06-18 11:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-06-18 11:00:00
26	6	2	2026-06-25 12:00:00	completed	2500.00	Sample analysis completed	\N	\N	\N	\N	2026-06-25 12:00:00
27	10	2	2026-07-07 09:00:00	completed	1000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
28	11	2	2026-07-14 10:00:00	completed	1500.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
29	12	2	2026-07-21 11:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-21 11:00:00
30	13	2	2026-07-28 12:00:00	completed	2500.00	Sample analysis completed	\N	\N	\N	\N	2026-07-28 12:00:00
31	6	2	2026-07-05 13:00:00	completed	3500.00	Sample analysis completed	\N	\N	\N	\N	2026-07-05 13:00:00
32	10	2	2026-08-10 09:00:00	completed	1000.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
33	11	2	2026-08-17 10:00:00	completed	1500.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
34	12	2	2026-08-24 11:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-08-24 11:00:00
35	13	2	2026-08-01 12:00:00	completed	2500.00	Sample analysis completed	\N	\N	\N	\N	2026-08-01 12:00:00
36	6	2	2026-09-13 09:00:00	completed	1000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
37	10	2	2026-09-20 10:00:00	completed	1500.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
38	11	2	2026-09-27 11:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
39	12	2	2026-09-05 12:00:00	completed	2500.00	Sample analysis completed	\N	\N	\N	\N	2026-09-05 12:00:00
40	13	2	2026-09-12 13:00:00	completed	3500.00	Sample analysis completed	\N	\N	\N	\N	2026-09-12 13:00:00
41	6	2	2026-10-16 09:00:00	completed	1000.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
42	10	2	2026-10-06 10:00:00	completed	1500.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
43	11	2	2026-10-13 11:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-10-13 11:00:00
44	12	2	2026-10-03 12:00:00	completed	2500.00	Sample analysis completed	\N	\N	\N	\N	2026-10-03 12:00:00
45	13	3	2026-05-01 09:00:00	completed	5000.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
46	6	3	2026-06-04 09:00:00	completed	5000.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
47	10	3	2026-06-11 10:00:00	completed	7500.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
48	11	3	2026-07-07 09:00:00	completed	5000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
49	12	3	2026-07-14 10:00:00	completed	7500.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
50	13	3	2026-07-21 11:00:00	completed	10000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-21 11:00:00
51	6	3	2026-08-10 09:00:00	completed	5000.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
52	10	3	2026-08-17 10:00:00	completed	7500.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
53	11	3	2026-09-13 09:00:00	completed	5000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
54	12	3	2026-09-20 10:00:00	completed	7500.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
55	13	3	2026-09-27 11:00:00	completed	10000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
56	6	3	2026-10-16 09:00:00	completed	5000.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
57	10	3	2026-10-06 10:00:00	completed	7500.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
58	11	4	2026-05-01 09:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
59	12	4	2026-05-08 10:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-05-08 10:00:00
60	13	4	2026-06-04 09:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
61	6	4	2026-06-11 10:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
62	10	4	2026-06-18 11:00:00	completed	3200.00	Sample analysis completed	\N	\N	\N	\N	2026-06-18 11:00:00
63	11	4	2026-07-07 09:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
64	12	4	2026-07-14 10:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
65	13	4	2026-07-21 11:00:00	completed	3200.00	Sample analysis completed	\N	\N	\N	\N	2026-07-21 11:00:00
66	6	4	2026-07-28 12:00:00	completed	4800.00	Sample analysis completed	\N	\N	\N	\N	2026-07-28 12:00:00
67	10	4	2026-08-10 09:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
68	11	4	2026-08-17 10:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
69	12	4	2026-08-24 11:00:00	completed	3200.00	Sample analysis completed	\N	\N	\N	\N	2026-08-24 11:00:00
70	13	4	2026-09-13 09:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
71	6	4	2026-09-20 10:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
72	10	4	2026-09-27 11:00:00	completed	3200.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
73	11	4	2026-09-05 12:00:00	completed	4800.00	Sample analysis completed	\N	\N	\N	\N	2026-09-05 12:00:00
74	12	4	2026-10-16 09:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
75	13	4	2026-10-06 10:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
76	6	4	2026-10-13 11:00:00	completed	3200.00	Sample analysis completed	\N	\N	\N	\N	2026-10-13 11:00:00
77	10	5	2026-05-01 09:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
78	11	5	2026-05-08 10:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-05-08 10:00:00
79	12	5	2026-06-04 09:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
80	13	5	2026-06-11 10:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
81	6	5	2026-07-07 09:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
82	10	5	2026-07-14 10:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
83	11	5	2026-07-21 11:00:00	completed	4000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-21 11:00:00
84	12	5	2026-08-10 09:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
85	13	5	2026-08-17 10:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
86	6	5	2026-09-13 09:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
87	10	5	2026-09-20 10:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
88	11	5	2026-09-27 11:00:00	completed	4000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
89	12	5	2026-10-16 09:00:00	completed	2000.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
90	13	5	2026-10-06 10:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
91	6	6	2026-05-01 09:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
92	10	6	2026-06-04 09:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
93	11	6	2026-06-11 10:00:00	completed	4500.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
94	12	6	2026-07-07 09:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
95	13	6	2026-07-14 10:00:00	completed	4500.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
96	6	6	2026-08-10 09:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
97	10	6	2026-08-17 10:00:00	completed	4500.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
98	11	6	2026-08-24 11:00:00	completed	6000.00	Sample analysis completed	\N	\N	\N	\N	2026-08-24 11:00:00
99	12	6	2026-09-13 09:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
100	13	6	2026-09-20 10:00:00	completed	4500.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
101	6	6	2026-10-16 09:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
102	10	6	2026-10-06 10:00:00	completed	4500.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
103	11	7	2026-05-01 09:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
104	12	7	2026-05-08 10:00:00	completed	1800.00	Sample analysis completed	\N	\N	\N	\N	2026-05-08 10:00:00
105	13	7	2026-06-04 09:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
106	6	7	2026-06-11 10:00:00	completed	1800.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
107	10	7	2026-06-18 11:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-06-18 11:00:00
108	11	7	2026-07-07 09:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
109	12	7	2026-07-14 10:00:00	completed	1800.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
110	13	7	2026-07-21 11:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-07-21 11:00:00
111	6	7	2026-08-10 09:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
112	10	7	2026-08-17 10:00:00	completed	1800.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
113	11	7	2026-08-24 11:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-08-24 11:00:00
114	12	7	2026-09-13 09:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
115	13	7	2026-09-20 10:00:00	completed	1800.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
116	6	7	2026-09-27 11:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
117	10	7	2026-09-05 12:00:00	completed	3000.00	Sample analysis completed	\N	\N	\N	\N	2026-09-05 12:00:00
118	11	7	2026-10-16 09:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
119	12	7	2026-10-06 10:00:00	completed	1800.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
120	13	7	2026-10-13 11:00:00	completed	2400.00	Sample analysis completed	\N	\N	\N	\N	2026-10-13 11:00:00
121	6	8	2026-05-01 09:00:00	completed	800.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
122	10	8	2026-05-08 10:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-05-08 10:00:00
123	11	8	2026-06-04 09:00:00	completed	800.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
124	12	8	2026-06-11 10:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
125	13	8	2026-06-18 11:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-06-18 11:00:00
126	6	8	2026-07-07 09:00:00	completed	800.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
127	10	8	2026-07-14 10:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
128	11	8	2026-07-21 11:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-07-21 11:00:00
129	12	8	2026-08-10 09:00:00	completed	800.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
130	13	8	2026-08-17 10:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
131	6	8	2026-09-13 09:00:00	completed	800.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
132	10	8	2026-09-20 10:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
133	11	8	2026-09-27 11:00:00	completed	1600.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
134	12	8	2026-10-16 09:00:00	completed	800.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
135	13	8	2026-10-06 10:00:00	completed	1200.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
136	6	9	2026-05-01 09:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-05-01 09:00:00
137	10	9	2026-06-04 09:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-06-04 09:00:00
138	11	9	2026-06-11 10:00:00	completed	5400.00	Sample analysis completed	\N	\N	\N	\N	2026-06-11 10:00:00
139	12	9	2026-07-07 09:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-07-07 09:00:00
140	13	9	2026-07-14 10:00:00	completed	5400.00	Sample analysis completed	\N	\N	\N	\N	2026-07-14 10:00:00
141	6	9	2026-08-10 09:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-08-10 09:00:00
142	10	9	2026-08-17 10:00:00	completed	5400.00	Sample analysis completed	\N	\N	\N	\N	2026-08-17 10:00:00
143	11	9	2026-09-13 09:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-09-13 09:00:00
144	12	9	2026-09-20 10:00:00	completed	5400.00	Sample analysis completed	\N	\N	\N	\N	2026-09-20 10:00:00
145	13	9	2026-09-27 11:00:00	completed	7200.00	Sample analysis completed	\N	\N	\N	\N	2026-09-27 11:00:00
146	6	9	2026-10-16 09:00:00	completed	3600.00	Sample analysis completed	\N	\N	\N	\N	2026-10-16 09:00:00
147	10	9	2026-10-06 10:00:00	completed	5400.00	Sample analysis completed	\N	\N	\N	\N	2026-10-06 10:00:00
\.


--
-- Data for Name: configurations; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.configurations (id, "officeEmail", registration_category_field_id, istem_token, istem_token_expires_at, istem_user_mapping, istem_equipment_mapping, istem_static_defaults, registration_name_field_id) FROM stdin;
1	sif@nitt.edu	4	\N	\N	\N	\N	\N	3
\.


--
-- Data for Name: equipments; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.equipments (id, name, code, active, istem_id, istem_synced_at, updated_at, istem_booking_mapping, make, model, department_lab, usage_rate, serial_number, location, website_url, description) FROM stdin;
1	Field Emission Scanning Electron Microscope (FE-SEM)	FESEM-01	t	\N	\N	2026-10-17 22:14:19.312992	\N			Central Characterization Lab	1200/hr				
2	X-Ray Diffractometer (XRD)	XRD-01	t	\N	\N	2026-10-17 22:14:19.314363	\N			Materials Science Lab	500/sample				
3	High-Resolution Transmission Electron Microscope (HR-TEM)	HRTEM-01	t	\N	\N	2026-10-17 22:14:19.315187	\N			Nanotechnology Center	2500/hr				
4	Nuclear Magnetic Resonance Spectrometer (500 MHz NMR)	NMR-500	t	\N	\N	2026-10-17 22:14:19.316064	\N			Chemistry Research Lab	800/sample				
5	Atomic Force Microscope (AFM)	AFM-01	t	\N	\N	2026-10-17 22:40:11.56624	\N			Nanotechnology Center	1000/hr				
6	Confocal Laser Scanning Microscope (CLSM)	CLSM-01	t	\N	\N	2026-10-17 22:40:11.567094	\N			Bio-Imaging Center	1500/hr				
7	Thermogravimetric Analyzer (TGA/DSC)	TGA-01	t	\N	\N	2026-10-17 22:40:11.567757	\N			Thermal Analysis Lab	600/sample				
8	UV-Vis-NIR Spectrophotometer	UV-VIS-01	t	\N	\N	2026-10-17 22:40:11.568434	\N			Optics & Spectroscopy Lab	400/sample				
9	Inductively Coupled Plasma Mass Spectrometer (ICP-MS)	ICPMS-01	t	\N	\N	2026-10-17 22:40:11.569155	\N			Analytical Chemistry Lab	1800/sample				
\.


--
-- Data for Name: field_admin_files; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.field_admin_files (id, field_id, file_path, original_name) FROM stdin;
\.


--
-- Data for Name: field_groups; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.field_groups (id, field_id, max) FROM stdin;
\.


--
-- Data for Name: field_options; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.field_options (id, field_id, value) FROM stdin;
1	4	Internal Student
2	4	Internal Faculty
3	4	External Academic
4	4	Industry
\.


--
-- Data for Name: field_relations; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.field_relations (id, field_id, related_entity_type, related_field_id) FROM stdin;
\.


--
-- Data for Name: field_responses; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.field_responses (id, entity_type, entity_id, field_id, value, user_id, booking_id, iteration, admin_value) FROM stdin;
25	registration	1	3	Roshan Ramsa	\N	\N	0	\N
26	registration	1	4	Internal Student	\N	\N	0	\N
27	registration	1	5	Computer Applications, NIT Trichy	\N	\N	0	\N
7	registration	3	3	Dr. Vikram Patel	\N	\N	0	\N
8	registration	3	4	External Academic	\N	\N	0	\N
9	registration	3	5	Department of Physics, IIT Madras	\N	\N	0	\N
10	registration	3	1	vikram.patel.res@gmail.com	\N	\N	0	\N
11	registration	3	2	9876500022	\N	\N	0	\N
12	registration	4	3	Kavitha R.	\N	\N	0	\N
13	registration	4	4	Industry	\N	\N	0	\N
14	registration	4	5	Biotech Innovations Ltd	\N	\N	0	\N
15	registration	4	1	kavitha.biotech@gmail.com	\N	\N	0	\N
16	registration	4	2	9876500033	\N	\N	0	\N
17	registration	5	3	Suresh Kumar	\N	\N	0	\N
18	registration	5	4	Internal Student	\N	\N	0	\N
19	registration	5	5	Metallurgical & Materials Engineering	\N	\N	0	\N
28	registration	8	3	Rahul Verma	\N	\N	0	\N
29	registration	8	4	Internal Student	\N	\N	0	\N
30	registration	8	5	Physics Department	\N	\N	0	\N
31	registration	9	3	Prof. K. Ramesh	\N	\N	0	\N
32	registration	9	4	Internal Faculty	\N	\N	0	\N
33	registration	9	5	Mechanical Engineering, NIT Trichy	\N	\N	0	\N
34	registration	10	3	Dr. Arun Kumar	\N	\N	0	\N
35	registration	10	4	External Academic	\N	\N	0	\N
36	registration	10	5	Centre for Research in Nanotechnology, IIT Bombay	\N	\N	0	\N
37	registration	11	3	Dr. Meena Swaminathan	\N	\N	0	\N
38	registration	11	4	Industry	\N	\N	0	\N
39	registration	11	5	Biocon Biologics R&D	\N	\N	0	\N
20	registration	6	3	Priya Nair	\N	\N	0	\N
21	registration	6	4	Internal Student	\N	\N	0	\N
22	registration	6	5	Department of Chemistry	\N	\N	0	\N
23	registration	7	3	Test Applicant	\N	\N	0	\N
24	registration	7	4	External Academic	\N	\N	0	\N
2	registration	2	3	Ananya Sharma	\N	\N	0	\N
3	registration	2	4	Internal Student	\N	\N	0	\N
4	registration	2	5	Chemical Engineering, NIT Trichy	\N	\N	0	\N
5	registration	2	1	ananya.personal@gmail.com	\N	\N	0	\N
6	registration	2	2	9876500011	\N	\N	0	\N
\.


--
-- Data for Name: fields; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.fields (id, entity_type, name, type, "order", active, entity_id, parent_id, stage, required) FROM stdin;
1	registration	Alternate Email	text	1	t	\N	\N	initial	f
2	registration	Alternate Mobile	text	2	t	\N	\N	initial	f
3	registration	Full Name	text	1	t	\N	\N	initial	t
4	registration	Category	single_select	2	t	\N	\N	initial	t
5	registration	Department / Organization	text	3	t	\N	\N	initial	f
\.


--
-- Data for Name: operator_equipments; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.operator_equipments (id, operator_id, equipment_id) FROM stdin;
1	3	1
2	3	2
3	4	3
4	5	4
11	3	5
13	4	6
15	5	7
16	5	8
17	5	9
30	3	7
\.


--
-- Data for Name: otp_verifications; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.otp_verifications (id, type, target, otp_hash, expires_at, attempts, verified, turnstile_token, created_at) FROM stdin;
1	email	roshanramsa@gmail.com	$2b$10$0.PzIaXPA0ZfMNQ8.Dynf.z1N45POjqzjFjMTxur9UQYSTc.cty8.	2026-10-13 17:29:56.728	0	f	XXXX.DUMMY.TOKEN.XXXX	2026-10-13 17:19:56.731042
2	email	roshanramsa@gmail.com	$2b$10$dHx7s4AiDP8oPkXysuLbHO107uyKDRg29uVxT/xn8yVfmylhVq0yG	2026-10-13 17:30:12.951	0	f	XXXX.DUMMY.TOKEN.XXXX	2026-10-13 17:20:12.95293
3	email	roshanramsa@gmail.com	$2b$10$aa/WXsRtEn5YUr1dENIbc.pSNTMev/2YHUgnsFGnvEiSArnnNyV4y	2026-10-13 17:34:29.31	0	f	dummy	2026-10-13 17:24:29.311712
4	email	newuser999@nitt.edu	$2b$10$aYKngeYwzhQOT8nX4xD/c.sOhSs.KVoTRRPYitPGO3PT81b68T4mm	2026-10-13 17:42:35.372	0	f	dummy	2026-10-13 17:32:35.374336
5	email	testunique777@nitt.edu	$2b$10$mhgR7UEAUfjB6qXu7k0VL.qFhYNNrizspwg./EXhBMkSBioxWqLP6	2026-10-13 17:50:50.948	0	f	dummy	2026-10-13 17:40:50.951292
6	email	testunique999@nitt.edu	$2b$10$QdLrqtUNibhqBX2JlYYqn.pFlUzj8Tni0EB3bOKztxYLgfyckjPTa	2026-10-13 18:07:57.281	0	f	1x00000000000000000000AA	2026-10-13 17:57:57.28305
7	email	testverifyfinal@nitt.edu	$2b$10$bSxEyZyvX58OOlEbPlhoAuJSMgJO1HEPFbPIIBHUlaN5vcBnoT6NS	2026-10-13 18:11:06.25	0	f	1x00000000000000000000AA	2026-10-13 18:01:06.253284
8	email	roshanramsa@gmail.com	$2b$10$h7N3zyxpqWkK.i2vpfYLKe2RzqbibVTXXM6VBEZUyv2QELAbl.aHW	2026-10-13 18:12:42.035	1	f	XXXX.DUMMY.TOKEN.XXXX	2026-10-13 18:02:42.036631
\.


--
-- Data for Name: registrations; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.registrations (id, password, email, phone, created_at, accepted, rejection_reason) FROM stdin;
1	$2b$10$kLxOIkADy3GzkmX6gBcIqu9ZmhJQRhNsusAW827iCPkMgSggHwcI2	roshanramsa@gmail.com	9360474446	2026-10-13 18:10:33.561632	t	\N
8	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	rahul.verma@nitt.edu	9876500015	2026-10-17 22:40:11.597344	t	\N
9	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	prof.ramesh@nitt.edu	9876500016	2026-10-17 22:40:11.601766	t	\N
10	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	dr.arun.kumar@iitb.ac.in	9876500017	2026-10-17 22:40:11.605952	t	\N
11	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	dr.meena@biocon.com	9876500018	2026-10-17 22:40:11.60944	t	\N
2	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	ananya.sharma@nitt.edu	9876500001	2026-10-17 22:14:19.324541	\N	\N
3	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	dr.vikram.patel@iitm.ac.in	9876500002	2026-10-17 22:14:19.330802	\N	\N
4	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	contact@biotech-innovations.com	9876500003	2026-10-17 22:14:19.335318	\N	\N
5	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	suresh.kumar@nitt.edu	9876500004	2026-10-17 22:14:19.339673	\N	\N
6	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	priya.nair@nitt.edu	9876500005	2026-10-17 22:14:19.343039	t	\N
7	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	fake.applicant@test.com	9876500006	2026-10-17 22:14:19.346616	f	Institutional identity verification failed: ID card proof expired.
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: db_user
--

COPY public.users (id, username, password, role, registration_id, reset_password_token, reset_password_expires, active, istem_id, istem_synced_at, updated_at) FROM stdin;
1	roshanramsa@gmail.com	$2b$10$kLxOIkADy3GzkmX6gBcIqu9ZmhJQRhNsusAW827iCPkMgSggHwcI2	public	1	\N	\N	t	\N	\N	2026-10-13 18:17:16.596001
6	priya.nair@nitt.edu	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	public	6	\N	\N	t	\N	\N	2026-10-17 22:14:19.345852
8	suresh.kumar@nitt.edu	$2b$10$JE4KJl8LdKcc/xjMQQyLjODUmtW32U83smynjYVVmHotNKoYtOd0W	public	5	\N	\N	t	\N	\N	2026-10-17 22:19:51.051008
10	rahul.verma@nitt.edu	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	public	8	\N	\N	t	\N	\N	2026-10-17 22:40:11.600845
11	prof.ramesh@nitt.edu	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	public	9	\N	\N	t	\N	\N	2026-10-17 22:40:11.605183
12	dr.arun.kumar@iitb.ac.in	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	public	10	\N	\N	t	\N	\N	2026-10-17 22:40:11.608651
13	dr.meena@biocon.com	$2b$10$r6LgpUNh.MpqlfjsRkuxau4kbhpkgRD8PYGt2JSthZXANG0y.q7Eu	public	11	\N	\N	t	\N	\N	2026-10-17 22:40:11.612993
2	admin	$2b$10$KP7KCCV.eaEhpOADTSGx2e02RAPk7EdahHmBruzr8YbWkqZv0rPz2	admin	\N	\N	\N	t	\N	\N	2026-10-17 21:57:30.495297
3	operator_fesem	$2b$10$wI8zMxTi0G/qSImOb/laDeU4qYGMUZ5XMDcQ/AtigOm80pE3yl8rq	operator	\N	\N	\N	t	\N	\N	2026-10-17 22:14:19.317639
4	operator_tem	$2b$10$wI8zMxTi0G/qSImOb/laDeU4qYGMUZ5XMDcQ/AtigOm80pE3yl8rq	operator	\N	\N	\N	t	\N	\N	2026-10-17 22:14:19.321027
5	operator_nmr	$2b$10$wI8zMxTi0G/qSImOb/laDeU4qYGMUZ5XMDcQ/AtigOm80pE3yl8rq	operator	\N	\N	\N	t	\N	\N	2026-10-17 22:14:19.322666
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: db_user
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 19, true);


--
-- Name: bookings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.bookings_id_seq', 147, true);


--
-- Name: configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.configurations_id_seq', 1, true);


--
-- Name: equipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.equipments_id_seq', 9, true);


--
-- Name: field_admin_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.field_admin_files_id_seq', 1, false);


--
-- Name: field_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.field_groups_id_seq', 1, false);


--
-- Name: field_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.field_options_id_seq', 4, true);


--
-- Name: field_relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.field_relations_id_seq', 1, false);


--
-- Name: field_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.field_responses_id_seq', 39, true);


--
-- Name: fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.fields_id_seq', 5, true);


--
-- Name: operator_equipments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.operator_equipments_id_seq', 44, true);


--
-- Name: otp_verifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.otp_verifications_id_seq', 8, true);


--
-- Name: registrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.registrations_id_seq', 11, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: db_user
--

SELECT pg_catalog.setval('public.users_id_seq', 16, true);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: db_user
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: configurations configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.configurations
    ADD CONSTRAINT configurations_pkey PRIMARY KEY (id);


--
-- Name: equipments equipments_code_unique; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.equipments
    ADD CONSTRAINT equipments_code_unique UNIQUE (code);


--
-- Name: equipments equipments_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.equipments
    ADD CONSTRAINT equipments_pkey PRIMARY KEY (id);


--
-- Name: field_admin_files field_admin_files_field_id_unique; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_admin_files
    ADD CONSTRAINT field_admin_files_field_id_unique UNIQUE (field_id);


--
-- Name: field_admin_files field_admin_files_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_admin_files
    ADD CONSTRAINT field_admin_files_pkey PRIMARY KEY (id);


--
-- Name: field_groups field_groups_field_id_unique; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_groups
    ADD CONSTRAINT field_groups_field_id_unique UNIQUE (field_id);


--
-- Name: field_groups field_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_groups
    ADD CONSTRAINT field_groups_pkey PRIMARY KEY (id);


--
-- Name: field_options field_options_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_options
    ADD CONSTRAINT field_options_pkey PRIMARY KEY (id);


--
-- Name: field_relations field_relations_field_id_unique; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_relations
    ADD CONSTRAINT field_relations_field_id_unique UNIQUE (field_id);


--
-- Name: field_relations field_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_relations
    ADD CONSTRAINT field_relations_pkey PRIMARY KEY (id);


--
-- Name: field_responses field_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_responses
    ADD CONSTRAINT field_responses_pkey PRIMARY KEY (id);


--
-- Name: fields fields_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.fields
    ADD CONSTRAINT fields_pkey PRIMARY KEY (id);


--
-- Name: operator_equipments operator_equipments_operator_equipment_unique; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.operator_equipments
    ADD CONSTRAINT operator_equipments_operator_equipment_unique UNIQUE (operator_id, equipment_id);


--
-- Name: operator_equipments operator_equipments_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.operator_equipments
    ADD CONSTRAINT operator_equipments_pkey PRIMARY KEY (id);


--
-- Name: otp_verifications otp_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.otp_verifications
    ADD CONSTRAINT otp_verifications_pkey PRIMARY KEY (id);


--
-- Name: registrations registrations_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.registrations
    ADD CONSTRAINT registrations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: bookings bookings_equipment_id_equipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_equipment_id_equipments_id_fk FOREIGN KEY (equipment_id) REFERENCES public.equipments(id) ON DELETE CASCADE;


--
-- Name: bookings bookings_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: configurations configurations_registration_category_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.configurations
    ADD CONSTRAINT configurations_registration_category_field_id_fields_id_fk FOREIGN KEY (registration_category_field_id) REFERENCES public.fields(id) ON DELETE SET NULL;


--
-- Name: configurations configurations_registration_name_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.configurations
    ADD CONSTRAINT configurations_registration_name_field_id_fields_id_fk FOREIGN KEY (registration_name_field_id) REFERENCES public.fields(id) ON DELETE SET NULL;


--
-- Name: field_admin_files field_admin_files_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_admin_files
    ADD CONSTRAINT field_admin_files_field_id_fields_id_fk FOREIGN KEY (field_id) REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: field_groups field_groups_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_groups
    ADD CONSTRAINT field_groups_field_id_fields_id_fk FOREIGN KEY (field_id) REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: field_options field_options_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_options
    ADD CONSTRAINT field_options_field_id_fields_id_fk FOREIGN KEY (field_id) REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: field_relations field_relations_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_relations
    ADD CONSTRAINT field_relations_field_id_fields_id_fk FOREIGN KEY (field_id) REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: field_relations field_relations_related_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_relations
    ADD CONSTRAINT field_relations_related_field_id_fields_id_fk FOREIGN KEY (related_field_id) REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: field_responses field_responses_booking_id_bookings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_responses
    ADD CONSTRAINT field_responses_booking_id_bookings_id_fk FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE CASCADE;


--
-- Name: field_responses field_responses_field_id_fields_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_responses
    ADD CONSTRAINT field_responses_field_id_fields_id_fk FOREIGN KEY (field_id) REFERENCES public.fields(id) ON DELETE CASCADE;


--
-- Name: field_responses field_responses_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.field_responses
    ADD CONSTRAINT field_responses_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: operator_equipments operator_equipments_equipment_id_equipments_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.operator_equipments
    ADD CONSTRAINT operator_equipments_equipment_id_equipments_id_fk FOREIGN KEY (equipment_id) REFERENCES public.equipments(id) ON DELETE CASCADE;


--
-- Name: operator_equipments operator_equipments_operator_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.operator_equipments
    ADD CONSTRAINT operator_equipments_operator_id_users_id_fk FOREIGN KEY (operator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_registration_id_registrations_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: db_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_registration_id_registrations_id_fk FOREIGN KEY (registration_id) REFERENCES public.registrations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict cFsfGM6nP0V3ZuTeOS3wtDanxPs4rUNwhuLGl3tzLddvYLByIdyIjWyy6KRlt2r

