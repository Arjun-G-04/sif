--
-- PostgreSQL database dump
--

\restrict qdkyFeNodCDDaklASTMLvxGcWCxNwiocnlAgFj1jLhqhKJTijUFikxJJcHAOJ2W

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict qdkyFeNodCDDaklASTMLvxGcWCxNwiocnlAgFj1jLhqhKJTijUFikxJJcHAOJ2W

